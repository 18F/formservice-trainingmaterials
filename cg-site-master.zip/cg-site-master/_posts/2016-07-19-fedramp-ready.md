---
layout: post
date: "2016-07-19"
title: "Full steam ahead on FedRAMP assessment"
redirect_from:
  - /updates/2016-07-19-fedramp-ready/
---

Over on the 18F team blog, [we've posted an update on cloud.gov's FedRAMP assessment progress](https://18f.gsa.gov/2016/07/18/cloud-gov-full-steam-ahead-fedramp-assessment-process/). In short: we've passed the FedRAMP Ready milestone, and we expect to receive FedRAMP Joint Authorization Board (JAB) Provisional Authority to Operate (P-ATO) in November. [More details in the post!](https://18f.gsa.gov/2016/07/18/cloud-gov-full-steam-ahead-fedramp-assessment-process/)
