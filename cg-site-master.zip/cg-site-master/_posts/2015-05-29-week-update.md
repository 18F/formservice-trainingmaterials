---
layout: post
date: "2015-05-29"
title: "Updates for the week of 5/29/2015"
redirect_from:
  - /updates/2015-05-29-week-update/
---

Platform:

- Upgraded to release [210](https://github.com/cloudfoundry/cf-release/releases/tag/v210)
- Binary and Static buildpacks are now built in the deployment
- Added Newrelic Insights and Plugins for platform monitoring data

Services:

- The rds service now encrypts the passwords
